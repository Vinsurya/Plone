from zope.i18nmessageid import MessageFactory
NGCollectionMessageFactory = MessageFactory('collective.portlet.ngcollection')


def initialize(context):
    """Initializer called when used as a Zope 2 product."""
