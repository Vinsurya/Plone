Changelog
=========

1.4 (2013-08-16)
----------------

 * Added z3cform portlet edit support
   [kroman0]

1.3.2 (2013-05-02)
------------------

 * Added French translations from transifex, thanks Marc Sokolovitch
   [kroman0, msoko]

1.3.1 (2013-02-12)
------------------

 * Fixed unexpected keyword argument error
   [kroman0]

1.3 (2013-01-17)
----------------

 * Fixed compatibility with Plone 4.3.x
   [kroman0]

1.2 (2012-01-23)
----------------

 * Fixed import deprecation and removed unused imports
   [mborch]

1.1 (2011-08-19)
----------------

 * fixed filesystem path binding
   [mylanium]

1.0 (2011-08-08)
----------------

 * long overdue release

0.1 (xxxx-xx-xx)
----------------

* Initial release
