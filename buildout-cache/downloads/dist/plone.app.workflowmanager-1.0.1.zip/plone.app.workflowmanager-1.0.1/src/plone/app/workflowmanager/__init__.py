#
from zope.i18nmessageid.message import MessageFactory
WMMessageFactory = MessageFactory('plone.app.workflowmanager')