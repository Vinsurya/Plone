from zope.interface import Interface

class ILocalBoardNotify(Interface):
    """
    Marker interface for Ploneboard objects that use local notification parameters
    """
