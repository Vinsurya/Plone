# -*- coding: utf-8 -*-

message = """<html>
<body>
<p>%(from)s</p>

<p>%(argument)s</p>
<p>%(message_intro)s</p>
%(message)s

<hr/>
<p><a href="%(url)s">%(url_text)s</a></p>
</body>
</html>
"""