# -*- coding: utf8 -*-

import logging

logger = logging.getLogger("Products.PloneboardNotify")

def initialize(context):
    """Initializer called when used as a Zope 2 product."""
