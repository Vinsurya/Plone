Tarjan Changelog
================

0.2.3 (2015-02-19)
------------------

- Fix packaging bug [#6]


0.2.2 (2015-02-18)
------------------

- Removed dynamic version specifier
- Converted docs to rst for better docs on pypi

Thanks-to: Patrick Gerken (github.com/d03cc)
