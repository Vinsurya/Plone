"""Generally useful components."""

# trigger registerType calls
import cardinality, contentreference, inverse, types
