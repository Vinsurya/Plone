====================
 dataflake.fakeldap
====================

This package offers a mock ``python-ldap`` library that can be used 
for testing code relying on ``python-ldap`` without having to configure 
and populate a real directory server.


Documentation
=============
Full documentation for the last released version is at
http://packages.python.org/dataflake.fakeldap. For 
documentation matching the current SVN trunk please visit 
http://docs.dataflake.org/dataflake.fakeldap.


Bug tracker
===========
A bug tracker is available at
https://bugs.launchpad.net/dataflake.fakeldap

