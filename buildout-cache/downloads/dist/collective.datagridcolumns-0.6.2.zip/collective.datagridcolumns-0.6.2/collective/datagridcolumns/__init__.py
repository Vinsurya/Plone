# -*- extra stuff goes here -*-

import logging

logger = logging.getLogger('collective.datagridcolumns')

def initialize(context):
    """Initializer called when used as a Zope 2 product."""
