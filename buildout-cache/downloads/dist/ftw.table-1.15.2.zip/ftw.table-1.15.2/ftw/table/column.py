METADATA = {
    'root': 'rows',
    'totalProperty': 'totalCount',
    'fields': [],
    'columns': [],
    }

FIELD = {'name': '',
         'type': 'string'}

COLUMN = {'id': '',
          'header': '',
          'dataIndex': ''}
