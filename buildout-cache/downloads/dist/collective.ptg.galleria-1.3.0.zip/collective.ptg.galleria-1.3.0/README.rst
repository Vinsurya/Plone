Introduction
============

Basic integration of the Galleria javascript gallery with collective.plonetruegallery
