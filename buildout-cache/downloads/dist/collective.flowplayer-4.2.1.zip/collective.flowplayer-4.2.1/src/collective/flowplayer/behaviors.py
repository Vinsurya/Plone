from zope.interface import Interface

class IFlowplayerFile(Interface):
    """Marker interface to indicate flowplayer support"""
