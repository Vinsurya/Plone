This directory containf Flowplayer and its support files.

Versions:

flowplayer.min.js           is flowplayer-3.2.11.min.js 
flowplayer.swf              is flowplayer-3.2.14.swf 
flowplayer.controls.swf     is flowplayer.controls-3.2.13.swf 
flowplayer.audio.swf        is flowplayer.audio-3.2.10.swf
flowplayer.playlist.min.js  is flowplayer.playlist-3.2.10.min.js 
flowplayer.ipad.min.js      is flowplayer.ipad-3.2.11.min.js 
flowplayer.rtmp.swf         is flowplayer.rtmp-3.2.11.swf
flowplayer.bwcheck.swf      is flowplayer.bwcheck-3.2.10.swf
flowplayer.pseudostreaming.swf is flowplayer.pseudostreaming-3.2.10.swf

Please update version list if any of files is changed.
