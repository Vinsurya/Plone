# -*- coding: utf-8 -*-

from z3c.form import interfaces


class ICSSClassWidget(interfaces.ISelectWidget):
    """CSSClass Select widget."""
