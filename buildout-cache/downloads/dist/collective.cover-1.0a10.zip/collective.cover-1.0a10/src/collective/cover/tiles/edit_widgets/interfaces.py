# -*- coding: utf-8 -*-

from z3c.form import interfaces


class IMoreLinkWidget(interfaces.IWidget):
    """More... link widget."""
