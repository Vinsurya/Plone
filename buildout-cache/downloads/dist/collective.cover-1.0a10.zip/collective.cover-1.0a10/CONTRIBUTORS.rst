Share and Enjoy
---------------

``collective.cover`` would not have been possible without the contribution of
the following people:

- André Nogueira
- Asko Soukka
- Carlos de la Guardia
- Cleber J. Santos
- Davi Lima
- Denis Krienbühl
- Érico Andrei
- Franco Pellegrini
- Fulvio Casali
- Giorgio Borelli
- Gonzalo Almeida
- Héctor Velarde
- JeanMichel FRANCOIS
- Juan A. Díaz
- Juan Pablo Giménez
- Kuno Woudt
- Laura Pérez Mayos
- Marcos F. Romero
- Maurits van Rees
- Rodrigo Ferreira de Souza
- Silvestre Huens
- Thiago Curvelo
- Thiago Tamosauskas
- `Launched Pixels`_ (icon)

You can find an updated list of package contributors on `GitHub`_.

Development sponsored by Open Multimedia, Ravvit and `Simples Consultoria`_.

.. _`Launched Pixels`: http://www.launchedpixels.com/
.. _`GitHub`: https://github.com/collective/collective.cover/contributors
.. _`Simples Consultoria`: http://www.simplesconsultoria.com.br/
