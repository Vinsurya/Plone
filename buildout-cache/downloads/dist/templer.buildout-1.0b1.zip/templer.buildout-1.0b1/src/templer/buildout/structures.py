from templer.core.structures import Structure


class BootstrapStructure(Structure):
    _structure_dir = 'structures/bootstrap'