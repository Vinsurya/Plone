Introduction
============

jQuery throttle / debounce allows you to rate-limit your functions in multiple useful ways.

See: http://benalman.com/projects/jquery-throttle-debounce-plugin/
Current plugin version: jQuery throttle / debounce - v1.1 - 3/7/2010

Credits
=======

Sponsered by `4teamwork`_.

 * `Jonas Baumann`_, author


.. _`4teamwork`: http://www.4teamwork.ch/
.. _`Jonas Baumann`: http://github.com/jone
