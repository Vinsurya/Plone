from App.Common import package_home
PACKAGE_HOME = package_home(globals())
