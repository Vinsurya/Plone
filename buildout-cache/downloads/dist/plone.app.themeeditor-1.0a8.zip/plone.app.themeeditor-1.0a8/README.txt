Overview
========

The theme editor makes it possible to customize most aspects of a plone theme from a single location.
After installation a new entry is added to the Plone "site setup" control panel called "Theme Editor."

Using the themeeditor
-----------------------

1. Log into your Plone site as a Manager 
2. Navigate to Site Setup
3. Select Theme Editor

Reporting Issues
-------------------

Visit https://dev.plone.org/plone and submit a ticket related to Theme Editor


