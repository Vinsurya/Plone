from zope.i18nmessageid import MessageFactory
PlominoMessageFactory = MessageFactory('CMFPlomino')
