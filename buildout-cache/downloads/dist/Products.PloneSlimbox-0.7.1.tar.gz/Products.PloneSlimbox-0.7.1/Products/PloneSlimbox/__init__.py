from Products.CMFCore.DirectoryView import registerDirectory
from config import *

registerDirectory('skins', GLOBALS)
