PROJECTNAME = "PloneSlimbox"
SKINNAME = "plone_slimbox"
GLOBALS=globals()
