.. contents::

- Code repository: http://svn.takanory.net/repos/Products.PloneSlimbox/
- Questions and comments to http://takanory.net/plone/develop/ploneslimbox/
- Report bugs at http://takanory.net/plone/develop/ploneslimbox/

