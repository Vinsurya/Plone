# package
from templer.core.basic_namespace import BasicNamespace
from templer.core.nested_namespace import NestedNamespace
