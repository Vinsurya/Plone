
=================
xhostplus.gallery
=================

An image gallery product for Plone 3 and 4. It consists of a special image
gallery folder, which can hold further image gallery folders and images, and a
portlet. The portlet shows random images of the configured image gallery.

The image gallery view is based on Plone's atct_album_view. This product
comes with an modified version of fancybox. It does not conflict with any
further installations of fancybox.

jQuery is required in order to run the gallery as it is supposed to be.

Translations
============

This product comes with following languages:

* English
* German

Further translations are welcome.

- Questions and comments to support@xhostplus.at
