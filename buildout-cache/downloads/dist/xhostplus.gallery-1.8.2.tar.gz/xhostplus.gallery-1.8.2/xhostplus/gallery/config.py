"""Common configuration constants
"""

PROJECTNAME = 'xhostplus.gallery'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-
    'ImageGallery': 'xhostplus.gallery: Add Image Gallery',
}
