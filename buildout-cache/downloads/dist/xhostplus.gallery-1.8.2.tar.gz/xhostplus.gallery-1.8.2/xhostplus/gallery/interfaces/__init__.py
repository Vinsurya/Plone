# -*- extra stuff goes here -*-
from imagegallery import IImageGallery

from zope.interface import Interface

class IProductLayer(Interface):
    """Browser layer for xhostplus.gallery product
    """
