import logging
from zope.i18nmessageid import MessageFactory

_ = MessageFactory("quintagroup.dropdownmenu")

PROJECT_NAME = "quintagroup.dropdownmenu"
logger = logging.getLogger(PROJECT_NAME)
