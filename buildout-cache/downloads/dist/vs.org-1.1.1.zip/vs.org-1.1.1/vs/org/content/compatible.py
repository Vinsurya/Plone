################################################################
# vs.org (C) 2011, Veit Schiele
################################################################

try:
    from Products.LinguaPlone import atapi
except ImportError:
    from Products.Archetypes import atapi
