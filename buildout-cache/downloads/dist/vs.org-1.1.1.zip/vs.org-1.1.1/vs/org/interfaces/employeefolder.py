################################################################
# vs.org (C) 2011, Veit Schiele
################################################################

# $Id: employeefolder.py 2981 2011-03-16 10:54:12Z carsten $

from zope.interface import Interface

class IEmployeefolder(Interface):
    """Folder for employees of an institution or department"""

