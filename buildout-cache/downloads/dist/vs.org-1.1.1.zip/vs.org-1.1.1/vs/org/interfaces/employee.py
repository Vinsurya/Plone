################################################################
# vs.org (C) 2011, Veit Schiele
################################################################

# $Id: employee.py 2981 2011-03-16 10:54:12Z carsten $

from zope.interface import Interface
# -*- Additional Imports Here -*-


class IEmployee(Interface):
    """Employee of an institution and/or departments"""

