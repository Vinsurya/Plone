# -*- coding: utf-8 -*-

################################################################
# vs.org (C) 2011, Veit Schiele
################################################################

# $Id$

from zope.interface import Interface


class IKeywordExtractor(Interface):
    """ Marker interface """

