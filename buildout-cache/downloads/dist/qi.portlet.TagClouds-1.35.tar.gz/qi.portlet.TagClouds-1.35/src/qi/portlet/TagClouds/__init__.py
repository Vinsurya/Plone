from zope.i18nmessageid import MessageFactory
TagCloudPortletMessageFactory = MessageFactory('qi.portlet.TagClouds')

def initialize(context):
    """Initializer called when used as a Zope 2 product."""
