Introduction
============

qi.portlet.TagClouds is a plone product that adds tag cloud portlet support. The following parameters of the portlet are configurable through the web:

* portlet title
* number of different tag sizes
* maximum tags to show
* content types searched (optionally)
* tags (subjects) searched (optionally)   
* section of the site to be searched
* workflow states searched
* filtering by keywords so that a tag cloud of all keywords that are combined
  with the filter keywords is shown

qi.portlet.TagClouds also comes with a simple caching mechanism. Cache remains
valid for a time interval that can be set in the portlet settings.
