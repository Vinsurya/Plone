Changelog
=========

1.5.3

- Modified the script so that links which contain megamenu would worked, cleaned css styles and js script for megamenu [roman.ischiv]

1.5.2

- Fixed styles for descktop  [roman.ischiv]

1.5.1

- Fixed support multilingual sites and styles [roman.ischiv]

1.5

- Fixed problem compatibility with plone.app.multilingual  [chervol]

1.4
---

- Fixed template and script [roman.ischiv]

1.3
---

- Fixed font-size [roman.ischiv]

1.2
---

- Added jQuery script [roman.ischiv]

1.1 
---

- Added megamenu presentation styles [roman.ischiv]

1.0 (unreleased)
-------------------

- Initial release