# To run the tests for this product, cd to the directory where you would normally run this command:
# bin/instance fg
# Instead, make sure Zope is not running, and type
# bin/test -s Products.ContentWellPortlets