# this package may contain traces of nuts

def initialize(registrar):
    pass
