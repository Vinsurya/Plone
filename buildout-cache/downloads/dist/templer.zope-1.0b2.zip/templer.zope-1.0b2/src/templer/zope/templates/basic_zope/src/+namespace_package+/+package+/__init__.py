
def initialize(registrar):
    pass
