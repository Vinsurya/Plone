"""Common configuration constants
"""

PROJECTNAME = 'ftw.tabbedview'

INDEXES = ()

METADATA = ()
