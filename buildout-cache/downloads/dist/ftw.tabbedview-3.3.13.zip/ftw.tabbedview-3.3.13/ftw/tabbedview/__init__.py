from zope.i18nmessageid import MessageFactory

tabbedviewMessageFactory = MessageFactory('ftw.tabbedview')
