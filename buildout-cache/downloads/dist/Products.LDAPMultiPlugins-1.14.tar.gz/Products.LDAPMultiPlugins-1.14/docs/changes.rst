.. include:: ../Products/LDAPMultiPlugins/CHANGES.txt
