(see Products/LDAPMultiPlugins/README.txt)
