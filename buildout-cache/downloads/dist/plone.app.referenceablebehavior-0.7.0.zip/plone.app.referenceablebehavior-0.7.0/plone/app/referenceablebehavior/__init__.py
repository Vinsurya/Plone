import zope.i18nmessageid
MessageFactory = zope.i18nmessageid.MessageFactory("plone.app.referenceablebehavior")


def initialize(context):
    """Initializer called when used as a Zope 2 product."""
