from plone.theme.interfaces import IDefaultPloneLayer

class IInnerfadeSpecific(IDefaultPloneLayer):
    """Marker interface that defines a Zope 3 browser layer.
    """