from plone.theme.interfaces import IDefaultPloneLayer


class IFtwPermissioneManager(IDefaultPloneLayer):
    """Marker interface for a zope 3 browser layer.
    """
