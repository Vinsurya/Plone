import zope.i18nmessageid

MessageFactory = zope.i18nmessageid.MessageFactory('collective.panels')
