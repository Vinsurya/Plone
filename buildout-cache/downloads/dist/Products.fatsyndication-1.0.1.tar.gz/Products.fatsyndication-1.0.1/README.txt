=======================
Products.fatsyndication
=======================

Generic syndication support for Archetypes content. For supported feed types see
package Products.basesyndication.

