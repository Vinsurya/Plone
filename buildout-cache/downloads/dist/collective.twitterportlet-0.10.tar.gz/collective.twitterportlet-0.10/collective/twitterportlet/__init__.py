from zope.i18nmessageid import MessageFactory
TwitterPortletMessageFactory = MessageFactory('collective.twitterportlet')
