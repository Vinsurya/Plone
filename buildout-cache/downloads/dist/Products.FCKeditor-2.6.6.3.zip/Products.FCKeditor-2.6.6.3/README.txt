========
README :
========


-----------------------------------------------------------------------------------
Introduction
-----------------------------------------------------------------------------------

This product is a FCKEditor Plone integration.
will be replaced in near future by a new package collective.ckeditor currently
available on svn only (developpement state)

For more information read documentation inside product :
 - "docs" folder contains all documentation
 - "_whatsnew.html", "_documentation.html" and "_upgrade.html" contain informations
   about the original FCKEditor product.  


------------------------------------------------------------------------------------
FCKeditor.Plone 2.6.6 - Plone product installation
------------------------------------------------------------------------------------


  FCKeditor.Plone 2.6.6 is based on FCKeditor 2.6.6 original code source.
  This package is Plone 3.xx and Plone 2.5.x compatible
  Since 2.4.3, Plone3 kss rich content edition is fully supported.

   Read docs/INSTALL.txt
   
   Go to your Plone Site > Plone Control Panel > Add Remove Products, 
   Choose FCKeditor ...
   or use Portal_QuickInstaller inside ZMI.
   
   Then read docs/FAQ.txt

   Upgrade : 
   read the upgrade help in docs/FAQ.txt
   
   download + install from SVN:
   read docs/SVN.txt (important)


     
--------------------------------------------------------------------------------------
Support
--------------------------------------------------------------------------------------
 support@ingeniweb.com

 Plone project page (infos, tracker, download ...) :
 http://plone.org/products/fckeditor
 
 Issues Tracker :
 http://trac.ingeniweb.com
 

 For more information about original editor:

 FCK Editor web site : http://fckeditor.net/ 
 FCK Editor dev trac : http://dev.fckeditor.net/


-------------------------------------------------------------------------------------
Copyright
-------------------------------------------------------------------------------------
 FCKeditor - The text editor for internet
 Version 2.6
 Copyright (C) 2003-2007 Frederico Caldeira Knabben
 Authors:
 Frederico Caldeira Knabben (fredck@fckeditor.net) 
 see license.txt
  


 FCKeditor.Plone  :
        Licensed under the terms of the following license :
        
         - GNU General Public License Version 2 or later (the "GPL")
           http://www.gnu.org/licenses/gpl.html
           (See Appendix A)
           
       Since June 2006 : (c) Ingeniweb - Alter Way Solutions - support@ingeniweb.com       
       Maintainers : Jean-mat Grimaldi, Gilles Lenfant, Youenn Boussard
       Thx to:
       Frederico and the FCKeditor community
       Ingeniweb boys and girls
       ... see old releases for all many thx
