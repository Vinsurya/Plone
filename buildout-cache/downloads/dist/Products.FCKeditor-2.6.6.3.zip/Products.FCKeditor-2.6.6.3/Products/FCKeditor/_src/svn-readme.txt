after a svn update
a "_src/fckeditor" directory must exist

Run utils/base2zope.py from python prompt before installing the product

