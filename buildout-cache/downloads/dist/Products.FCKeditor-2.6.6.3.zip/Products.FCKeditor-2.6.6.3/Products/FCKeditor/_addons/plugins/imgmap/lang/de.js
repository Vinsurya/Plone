FCKLang.imgmapBtn			= 'Image Map hinzufuegen/bearbeiten';
FCKLang.imgmapBtnRemove			= 'Map entfernen';
FCKLang.imgmapDlgTitle		= 'Image Map Editor';
FCKLang.imgmapDlgName		= 'ImageMapEditor';

FCKLang.msgImageNotSelected = 'Sie müssen erst ein Bild auswaehlen' ;

FCKLang.imgmapNoLabel = 'Keine Beschriftung' ;
FCKLang.imgmapLabelNumber = 'Mit Nummern beschriften' ;
FCKLang.imgmapLabelAlt = 'Mit Alternativtext beschriften' ;
FCKLang.imgmapLabelHref = 'Mit Link beschriften' ;
FCKLang.imgmapLabelTitle = 'Mit Titel beschriften' ;
FCKLang.imgmapLabelCoords = 'Mit Koordinaten beschriften' ;
FCKLang.imgmapLabelZoom = 'Zoom' ;

FCKLang.imgmapMap = 'Map' ;
FCKLang.imgmapMapName = 'Map name' ;
FCKLang.imgmapMapAreas = 'Image Map Bereiche' ;
FCKLang.DlgImgURL = 'Link';

FCKLang.imgmapPointer = 'Zeiger' ;
FCKLang.imgmapRectangle = 'Rechteck' ;
FCKLang.imgmapCircle = 'Kreis' ;
FCKLang.imgmapPolygon = 'Polygon' ;
FCKLang.imgmapDeleteArea = 'Ausgewählten Bereich löschen';
