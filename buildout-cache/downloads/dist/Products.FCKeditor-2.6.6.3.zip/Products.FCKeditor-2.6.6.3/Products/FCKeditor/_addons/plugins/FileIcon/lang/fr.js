/*
 * FCKeditor - The text editor for internet
 * Copyright (C) 2003-2004 Frederico Caldeira Knabben
 * 
 * Licensed under the terms of the GNU Lesser General Public License:
 * 		http://www.opensource.org/licenses/lgpl-license.php
 * 
 * For further information visit:
 * 		http://www.fckeditor.net/
 * 
 * File Name: fr.js
 * 	French language file for the file icon plugin.
 * 
 * Version:  1.0
 * Modified: 2008-06-18
 * 
 * File Authors:
 * 		Emmanuel Coirier (emmanuel.coirier@ingeniweb.com)
 */

FCKLang.DlgFileIconTitle = 'Ins�rer une ic�ne de fichier';
