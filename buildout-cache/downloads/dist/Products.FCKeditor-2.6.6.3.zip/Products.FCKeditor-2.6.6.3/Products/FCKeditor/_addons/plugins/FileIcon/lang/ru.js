/*
 * FCKeditor - The text editor for internet
 * Copyright (C) 2003-2004 Frederico Caldeira Knabben
 * 
 * Licensed under the terms of the GNU Lesser General Public License:
 * 		http://www.opensource.org/licenses/lgpl-license.php
 * 
 * For further information visit:
 * 		http://www.fckeditor.net/
 * 
 * File Name: ru.js
 * 	Russian language file for the file icon plugin.
 * 
 * Version:  2.0 RC3
 * Modified: 2005-01-27 11:20:10
 * 
 * File Authors:
 * 		Andrey Grebnev (andrey.grebnev@blandware.com)
 */

FCKLang['DlgFileIconTitle']			= 'Вставить иконку файла' ;
