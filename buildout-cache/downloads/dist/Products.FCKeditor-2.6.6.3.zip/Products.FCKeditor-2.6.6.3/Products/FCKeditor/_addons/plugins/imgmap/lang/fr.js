

FCKLang.imgmapBtn			= 'Ajouter/Editer Image Map';
FCKLang.imgmapBtnRemove			= 'Supprimer Image Map';
FCKLang.imgmapDlgTitle		= 'Editeur d\'Image Map';
FCKLang.imgmapDlgName		= 'ImageMapEditor';

FCKLang.msgImageNotSelected = 'Vous devez sélectionner une image avant d\'utiliser cette boîte de dialogue' ;

FCKLang.imgmapNoLabel = 'Pas de label' ;
FCKLang.imgmapLabelNumber = 'Label avec nombres' ;
FCKLang.imgmapLabelAlt = 'Label avec texte alternatif' ;
FCKLang.imgmapLabelHref = 'Label avec adresse url' ;
FCKLang.imgmapLabelTitle = 'Label avec titre' ;
FCKLang.imgmapLabelCoords = 'Label avec coordonnées' ;
FCKLang.imgmapLabelZoom = 'Zoom' ;

FCKLang.imgmapMap = 'Map' ;
FCKLang.imgmapMapName = 'Nom de l\'image map' ;
FCKLang.imgmapMapAreas = 'Zones de l\'image map' ;

FCKLang.imgmapPointer = 'Pointeur' ;
FCKLang.imgmapRectangle = 'Rectangle' ;
FCKLang.imgmapCircle = 'Cercle' ;
FCKLang.imgmapPolygon = 'Polygone' ;
FCKLang.imgmapDeleteArea = 'Supprimer la zone sélectionnée' ;

