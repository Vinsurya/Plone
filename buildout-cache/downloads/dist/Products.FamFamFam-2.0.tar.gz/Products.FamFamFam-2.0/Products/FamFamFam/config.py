PROJECTNAME = "FamFamFam"

product_globals = globals()