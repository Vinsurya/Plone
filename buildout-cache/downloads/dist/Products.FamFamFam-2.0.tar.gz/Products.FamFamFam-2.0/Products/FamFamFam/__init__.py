from Products.CMFCore import utils, DirectoryView
from Products.FamFamFam.config import *

DirectoryView.registerDirectory('skins', product_globals)
