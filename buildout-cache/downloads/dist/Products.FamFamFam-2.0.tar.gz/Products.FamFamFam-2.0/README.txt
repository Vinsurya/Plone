Introduction
============

Products.FamFamFam replaces the stock Plone icons with the icons
provided by http://www.famfamfam.com.

Plone 3 compatibility
---------------------

When using Plone 3 version 1.3 should be used since the icons where
converted to PNGs in Plone 4.
