ADD_REMOVE_PEOPLE = 'FacultyStaffDirectory: Add or Remove People',
ASSIGN_CLASSIFICATIONS_TO_PEOPLE = 'FacultyStaffDirectory: Assign Classifications to People'
ASSIGN_SPECIALTIES_TO_PEOPLE = 'FacultyStaffDirectory: Assign Specialties to People'
ASSIGN_COMMITTIES_TO_PEOPLE = 'FacultyStaffDirectory: Assign Committees to People'
ASSIGN_DEPARTMENTS_TO_PEOPLE = 'FacultyStaffDirectory: Assign Departments to People'
CHANGE_ROLES = 'FacultyStaffDirectory: Change roles' # used to guard workflow transitions between 'active' and 'inactive'
CHANGE_PERSON_IDS = 'FacultyStaffDirectory: Change Person IDs' # used to control write access to ID field of FSDPersons
PROVIDES_ROLES = 'FacultyStaffDirectory: Provides Roles' # used to control role inheritance via workflow
