# -*- coding: utf-8 -*-

__author__ = """WebLion <support@weblion.psu.edu>"""
__docformat__ = 'plaintext'

# Subpackages
import classification
import committee
import committeemembership
import course
import department
import departmentalmembership
import facultystaffdirectory
import facultystaffdirectorytool
import person
import specialtiesfolder
import specialty
import specialtyinformation