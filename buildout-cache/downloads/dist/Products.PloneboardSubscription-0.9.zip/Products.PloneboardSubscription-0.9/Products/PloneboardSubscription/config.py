"""
$Id: config.py 55779 2007-12-18 14:26:49Z fschulze $
"""
PROJECTNAME = "PloneboardSubscription"
I18N_DOMAIN = PROJECTNAME.lower()

GLOBALS = globals()
