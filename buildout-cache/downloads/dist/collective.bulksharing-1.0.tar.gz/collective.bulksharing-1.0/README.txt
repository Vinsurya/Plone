Introduction
============

This package is based on plone default roles sharing functionality and 
allows you to share roles in a bulk for multiple items.


Usage
-----

After installation in quickinstaller "Bulk sharing" button will appear inside
folder contents view. Inside that view select items to update, then click
"Bulk sharing" button and you'll be presented with Share local roles form.


Compatibility
-------------

Tested and working with Plone 4.x series.


Authors
-------

- Vitaliy Podoba
- Taras Melnychuk
