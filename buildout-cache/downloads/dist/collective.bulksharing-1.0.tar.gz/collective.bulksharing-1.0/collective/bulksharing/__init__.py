from zope.i18nmessageid import MessageFactory
PloneMessageFactory = MessageFactory('collective.bulksharing')
