from zope.i18nmessageid import MessageFactory

_ = MessageFactory('collective.blog.portlets')

def initialize(context):
    """Initializer called when used as a Zope 2 product."""
