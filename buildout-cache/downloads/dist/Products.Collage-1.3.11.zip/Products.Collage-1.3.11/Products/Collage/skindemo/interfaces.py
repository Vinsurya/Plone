from zope.interface import Interface

class IAlertSkin(Interface):
    """Interface for alert skins views."""
    pass
