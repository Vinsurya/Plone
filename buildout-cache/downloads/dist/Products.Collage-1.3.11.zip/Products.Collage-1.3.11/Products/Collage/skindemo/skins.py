class AlarmPortletSkin(object):

    # Lazyly untranslated title. In real life skinning, you should write:
    # title = _(u'skin_title', default=u"My skin title")

    title = "Alert portlet skin"

