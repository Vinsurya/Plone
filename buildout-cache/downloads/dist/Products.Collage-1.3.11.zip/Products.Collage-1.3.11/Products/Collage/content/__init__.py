# -*- coding: utf-8 -*-
# $Id$
"""Collage content types"""

from Products.Collage.content._collage import Collage
from Products.Collage.content._row import CollageRow
from Products.Collage.content._column import CollageColumn
from Products.Collage.content._alias import CollageAlias
