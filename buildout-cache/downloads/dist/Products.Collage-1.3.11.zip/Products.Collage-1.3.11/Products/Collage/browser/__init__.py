# -*- coding: utf-8 -*-
# $Id$
"""Browser package"""
