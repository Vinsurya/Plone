"""
Tests of Collage
"""
