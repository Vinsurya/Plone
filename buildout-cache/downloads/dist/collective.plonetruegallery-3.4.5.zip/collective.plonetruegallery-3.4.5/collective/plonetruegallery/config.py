PROJECTNAME = "collective.plonetruegallery"

# just so we don't get any collisions with other adapters...
named_adapter_prefix = "plonetruegallery_"

PAGE_SIZE = 15

DISPLAY_NAME_VIEW_PREFIX = 'galleryview-'
