__author__ = """Nathan Van Gheem"""
__docformat__ = 'plaintext'

from zope.i18nmessageid import MessageFactory
PTGMessageFactory = MessageFactory("collective.plonetruegallery")

import validators
