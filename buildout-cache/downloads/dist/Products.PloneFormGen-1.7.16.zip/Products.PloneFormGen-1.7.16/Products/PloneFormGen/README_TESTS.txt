Tests are not included in the Python Package distribution of PloneFormGen.

If you'd like to develop for PloneFormGen, please check out from svn
so that you'll have the test suite.