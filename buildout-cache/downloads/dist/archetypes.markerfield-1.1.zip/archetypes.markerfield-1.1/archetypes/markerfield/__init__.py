from archetypes.markerfield.field import InterfaceMarkerField

__all__ = (InterfaceMarkerField, )
