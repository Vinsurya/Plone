from zope.i18nmessageid import MessageFactory

LDAPMessageFactory = MessageFactory('plone.app.ldap')
