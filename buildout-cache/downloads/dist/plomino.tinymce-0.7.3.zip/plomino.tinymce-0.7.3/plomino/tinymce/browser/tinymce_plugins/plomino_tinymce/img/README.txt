Icons in this folder are extracted from the Oxygen Icons. See AUTHORS and copyright.
