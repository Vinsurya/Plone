tinyMCE.addI18n({fr:{
plomino_tinymce:{
field:"Ajouter/éditer un champ Plomino",
action:"Ajouter/éditer une action Plomino",
subform:"Ajouter/éditer un sous-formulaire Plomino",
hidewhen:"Ajouter/éditer une zone « Cacher quand… » Plomino",
edition_forbidden:"Vous devez sauvegarder ce formulaire avant d'utiliser ce bouton."
}}});
