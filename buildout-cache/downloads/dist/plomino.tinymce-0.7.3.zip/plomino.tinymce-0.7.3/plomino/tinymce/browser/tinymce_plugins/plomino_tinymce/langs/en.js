tinyMCE.addI18n({en:{
plomino_tinymce:{
field:"Add/edit a Plomino Field",
action:"Add/edit a Plomino Action",
subform:"Add a Plomino Sub-form",
hidewhen:"Add a Plomino Hiden-when zone",
edition_forbidden:"Please save the form before using this button."
}}});
