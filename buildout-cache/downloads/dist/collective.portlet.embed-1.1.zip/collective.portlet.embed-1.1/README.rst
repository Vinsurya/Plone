Introduction
============

This addon provide a new portlet: Embed portlet.

This portlet let you copy / paste HTML code from services like facebook, twitter, youtube and display the result in a portlet.

The portlet is based on the static portlet, so you have the same options: omit borders, more url, ...

You can find a demo at http://www.youtube.com/watch?v=it1hMtZKle8

Credits
=======

Companies
---------

|makinacom|_

  * `Planet Makina Corpus <http://www.makina-corpus.org>`_
  * `Contact us <mailto:python@makina-corpus.org>`_


Authors

  - JeanMichel FRANCOIS aka toutpt <toutpt@gmail.com>

Contributors

.. |makinacom| image:: http://depot.makina-corpus.org/public/logo.gif
.. _makinacom:  http://www.makina-corpus.com


